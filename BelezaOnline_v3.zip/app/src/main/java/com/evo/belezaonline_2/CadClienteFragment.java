package com.evo.belezaonline_2;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class CadClienteFragment extends Fragment {
    Button btCadas;
    EditText ctNome,ctEmail,ctUsu,ctSenha,ctRepSenha;

    String url="";
    String parametros="";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup fgContainer, Bundle savedInstanceState){
        View v= inflater.inflate(R.layout.fragment_cad_cliente, fgContainer,false);

        btCadas= v.findViewById(R.id.btCadas);
        ctNome= v.findViewById(R.id.ctNome);
        ctEmail= v.findViewById(R.id.ctEmailc);
        ctUsu= v.findViewById(R.id.ctUsuario);
        ctSenha= v.findViewById(R.id.ctSenha);
        ctRepSenha= v.findViewById(R.id.ctRepSenha);

        btCadas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectivityManager connMgr = (ConnectivityManager)getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

                if(networkInfo !=null && networkInfo.isConnected()){
                    String nome= ctNome.getText().toString();
                    String email= ctEmail.getText().toString();
                    String usuario= ctUsu.getText().toString();
                    String senha= ctSenha.getText().toString();
                    String repsenha= ctRepSenha.getText().toString();

                    if (usuario.isEmpty()||email.isEmpty()|| nome.isEmpty()|| senha.isEmpty() || repsenha.isEmpty()){
                        Toast.makeText(getContext(),"Há Campo(s) vazio(s)",Toast.LENGTH_LONG).show();
                    }else{
                        if (!senha.equals(repsenha)){
                            Toast.makeText(getContext(),"As senha não coincidem",Toast.LENGTH_SHORT).show();
                        }else{
                            url = "https://beleza-online.000webhostapp.com/cadastro.php";
                            parametros = "nome=" + nome +"&email="+email+ "&usuario=" + usuario + "&senha=" + senha;
                            new SolicitaDados().execute(url);
                        }
                    }
                }else{
                    Toast.makeText(getContext(),"Não há conexão com a internet.",Toast.LENGTH_LONG).show();
                }

            }
        });

        return v;
    }

    public static CadClienteFragment newInstance(){
        return new CadClienteFragment();
    }

    private class SolicitaDados extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            return Conexao.postDados(urls[0], parametros);
        }
        // onPostExecute mostra os resultados obtidos com a classe AsyncTask.
        @Override
        protected void onPostExecute(String resultado) {
            if(resultado != null && !resultado.isEmpty() && resultado.contains("Usuario_Erro")){
                Toast.makeText(getContext(),"Este e-mail já está cadastrado",Toast.LENGTH_LONG).show();
            }else if(resultado != null && !resultado.isEmpty() && resultado.contains("Registro_Ok")){
                Toast.makeText(getContext(),"Registro concluído com sucesso!",Toast.LENGTH_LONG).show();
                Intent abreInicio = new Intent(getActivity(),MainActivity.class);
                startActivity(abreInicio);
            }else{
                Toast.makeText(getContext(),"Ocorreu um erro: "+resultado,Toast.LENGTH_LONG).show();
            }
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        getActivity().getFragmentManager().popBackStack();
    }
}
