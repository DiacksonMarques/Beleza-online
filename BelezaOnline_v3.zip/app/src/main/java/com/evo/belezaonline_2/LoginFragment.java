package com.evo.belezaonline_2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {
    Button btIrCad;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup fgContainer, Bundle savedInstanceState){
        View v= inflater.inflate(R.layout.fragment_login, fgContainer,false);

        btIrCad= v.findViewById(R.id.btIrCad);
        btIrCad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String teste= "escadfrag";
                Intent intentircad = new Intent(getActivity(), MainActivity.class);
                intentircad.putExtra("transf",teste);
                startActivity(intentircad);
            }
        });

        return v;
    }

    public static LoginFragment newInstance(){
        return new LoginFragment();
    }
}

