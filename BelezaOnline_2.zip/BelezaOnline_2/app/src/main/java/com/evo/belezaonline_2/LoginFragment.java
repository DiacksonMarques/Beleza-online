package com.evo.belezaonline_2;

import android.os.Bundle;
import android.support.v4.app.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup fgContainer, Bundle savedInstanceState){
        return inflater.inflate(R.layout.fragment_login, fgContainer,false);
    }

    public static LoginFragment newInstance(){
        return new LoginFragment();
    }
}

