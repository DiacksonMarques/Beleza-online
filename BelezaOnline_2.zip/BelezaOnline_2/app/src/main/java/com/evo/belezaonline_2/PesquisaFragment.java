package com.evo.belezaonline_2;

import android.os.Bundle;
import android.support.v4.app.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

public class PesquisaFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup fgContainer, Bundle savedInstanceState){
        return inflater.inflate(R.layout.fragment_pesquisa, fgContainer, false);
    }

    public static Fragment newInstance(){
        return new PesquisaFragment();
    }
}
