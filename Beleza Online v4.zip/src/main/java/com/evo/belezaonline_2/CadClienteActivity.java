package com.evo.belezaonline_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadClienteActivity extends AppCompatActivity {
    Button btCadas;
    EditText ctNome,ctEmail,ctUsu,ctSenha,ctRepSenha;

    String url="";
    String parametros="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_cliente);

        btCadas=findViewById(R.id.btCadCli);
        ctNome= findViewById(R.id.ctNome);
        ctEmail= findViewById(R.id.ctEmailc);
        ctUsu= findViewById(R.id.ctUsuario);
        ctSenha= findViewById(R.id.ctSenhal);
        ctRepSenha= findViewById(R.id.ctRepSenha);

        btCadas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectivityManager connMgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

                if(networkInfo !=null && networkInfo.isConnected()){
                    String nome= ctNome.getText().toString();
                    String email= ctEmail.getText().toString();
                    String usuario= ctUsu.getText().toString();
                    String senha= ctSenha.getText().toString();
                    String repsenha= ctRepSenha.getText().toString();
                    String tipo_usuario= "cliente";

                    if (usuario.isEmpty()||email.isEmpty()|| nome.isEmpty()|| senha.isEmpty() || repsenha.isEmpty()){
                        Toast.makeText(getBaseContext(),"Há Campo(s) vazio(s)",Toast.LENGTH_LONG).show();
                    }else{
                        if (!senha.equals(repsenha)){
                            Toast.makeText(getBaseContext(),"As senha não coincidem",Toast.LENGTH_SHORT).show();
                        }else{
                            url = "https://beleza-online.000webhostapp.com/cadastro.php";
                            parametros = "nome=" + nome +"&email="+email+ "&usuario=" + usuario + "&senha=" + senha+"&tipo_usuario="+tipo_usuario;
                            new SolicitaDados().execute(url);
                        }
                    }
                }else{
                    Toast.makeText(getBaseContext(),"Não há conexão com a internet.",Toast.LENGTH_LONG).show();
                }

            }
        });
    }
    private class SolicitaDados extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            return Conexao.postDados(urls[0], parametros);
        }
        // onPostExecute mostra os resultados obtidos com a classe AsyncTask.
        @Override
        protected void onPostExecute(String resultado) {
            if(resultado != null && !resultado.isEmpty() && resultado.contains("Usuario_Erro")){
                Toast.makeText(getBaseContext(),"Este e-mail já está cadastrado",Toast.LENGTH_LONG).show();
            }else if(resultado != null && !resultado.isEmpty() && resultado.contains("Registro_Ok")){
                Toast.makeText(getBaseContext(),"Registro concluído com sucesso!",Toast.LENGTH_LONG).show();
                Intent abreInicio = new Intent(getBaseContext(),LoginActivity.class);
                startActivity(abreInicio);
            }else{
                Toast.makeText(getBaseContext(),"Ocorreu um erro: "+resultado,Toast.LENGTH_LONG).show();
            }
        }

    }
    @Override
    public void onPause(){
        super.onPause();
        finish();
    }
}
