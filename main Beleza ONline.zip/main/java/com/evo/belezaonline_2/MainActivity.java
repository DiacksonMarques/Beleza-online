package com.evo.belezaonline_2;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    TextView aux;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@Nullable MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Intent intent = new Intent(getBaseContext(),MainActivity.class);
                    startActivity(intent);
                    break;
                case R.id.navigation_pesquisa:
                    Fragment pesquisaFragment = PesquisaFragment.newInstance();
                    openFragment(pesquisaFragment);
                    break;
                case R.id.navigation_posts:
                    Fragment postFragment = PostFragment.newInstance();
                    openFragment(postFragment);
                    break;
                case R.id.navigation_usuario:
                    Fragment loginFragment = LoginFragment.newInstance();
                    openFragment(loginFragment);
                    break;
            }
            return true;
        }
    };

    private void openFragment(Fragment fragment){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fgContainer, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        aux = findViewById(R.id.aux);

        Intent intent = getIntent();
        String transf = intent.getStringExtra("transf");
        aux.setText(transf);
        String auxs = (String) aux.getText();
        switch (auxs){
            case "escadfrag":
                Fragment escocadfragment = EscoCadFragment.newInstance();
                openFragment(escocadfragment);
                break;

            case "cadcliente":
                Fragment cadclifragment = CadClienteFragment.newInstance();
                openFragment(cadclifragment);
                break;

            case "cadempresa":
                Fragment cademprefragmant = CadEmpresaFragment.newInstance();
                openFragment(cademprefragmant);
                break;
        }
    }

}
