package com.evo.belezaonline_2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

public class EscoCadFragment extends Fragment {
    Button btCliente,btNegocio;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup fgContainer, Bundle savedInstanceState){
        View v= inflater.inflate(R.layout.fragment_es_cad, fgContainer,false);

        btCliente= v.findViewById(R.id.btCliente);
        btCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cadcliente= "cadcliente";
                Intent intentcadcli = new Intent(getActivity(), MainActivity.class);
                intentcadcli.putExtra("transf",cadcliente);
                startActivity(intentcadcli);
            }
        });

        btNegocio= v.findViewById(R.id.btNegocio);
        btNegocio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cadempresa= "cadempresa";
                Intent intentcadcli = new Intent(getActivity(), MainActivity.class);
                intentcadcli.putExtra("transf",cadempresa);
                startActivity(intentcadcli);
            }
        });

        return v;
    }

    public static EscoCadFragment newInstance(){
        return new EscoCadFragment();
    }
}
